
import flask
print("Hello, World!")
# Print the Flask version
print("Flask version:", flask.__version__)
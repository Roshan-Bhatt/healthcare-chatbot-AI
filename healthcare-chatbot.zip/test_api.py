from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the fine-tuned model and tokenizer
model_path = './fine_tuned_model'
tokenizer = GPT2Tokenizer.from_pretrained(model_path)
model = GPT2LMHeadModel.from_pretrained(model_path)

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    inputs = tokenizer.encode(user_input, return_tensors='pt')
    outputs = model.generate(inputs, max_length=150, num_return_sequences=1)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)
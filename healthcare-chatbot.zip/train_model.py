import xml.etree.ElementTree as ET
import os
import re
from transformers import GPT2Tokenizer, GPT2LMHeadModel, Trainer, TrainingArguments, DataCollatorForLanguageModeling
from datasets import Dataset

def parse_pubmed_xml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    articles = []
    for article in root.findall('.//PubmedArticle'):
        title_element = article.find('.//ArticleTitle')
        abstract_element = article.find('.//AbstractText')
        if title_element is not None and abstract_element is not None:
            title = title_element.text
            abstract = abstract_element.text
            if title and abstract:
                articles.append(f"{title}\n{abstract}")
    return articles

def preprocess_text(text):
    # Remove special characters and extra spaces
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[^\w\s]', '', text)
    return text

def fine_tune_model(articles):
    tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    model = GPT2LMHeadModel.from_pretrained('gpt2')

    # Set the padding token
    tokenizer.pad_token = tokenizer.eos_token

    # Preprocess articles and create a dataset
    preprocessed_articles = [preprocess_text(article) for article in articles]
    dataset = Dataset.from_dict({"text": preprocessed_articles})
    dataset = dataset.map(lambda examples: tokenizer(examples["text"], truncation=True, padding="max_length", max_length=128), batched=True)
    dataset.set_format(type="torch", columns=["input_ids", "attention_mask"])

    # Debugging: Print the number of samples in the dataset
    print(f"Number of samples in the dataset: {len(dataset)}")

    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
    )

    training_args = TrainingArguments(
        output_dir='./results',
        overwrite_output_dir=True,
        num_train_epochs=3,
        per_device_train_batch_size=4,
        save_steps=10_000,
        save_total_limit=2,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        data_collator=data_collator,
        train_dataset=dataset,
    )

    trainer.train()
    model.save_pretrained('./fine_tuned_model')
    tokenizer.save_pretrained('./fine_tuned_model')

# Example usage
xml_file_path = r'd:/AI/healthcare-chatbot-env/test.xml'  # Update the file path
articles = parse_pubmed_xml(xml_file_path)

# Preprocess the articles
preprocessed_articles = [preprocess_text(article) for article in articles]

# Debugging: Print the number of preprocessed articles
print(f"Number of preprocessed articles: {len(preprocessed_articles)}")

# Fine-tune the model
print("Fine-tuning model...")
fine_tune_model(preprocessed_articles)